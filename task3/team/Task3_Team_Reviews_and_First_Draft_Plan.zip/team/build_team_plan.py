from pathlib import Path
from datetime import datetime
import json,re
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
out=Path(__file__).parent;doc=Document();sec=doc.sections[0];sec.top_margin=sec.bottom_margin=Cm(1.7);sec.left_margin=sec.right_margin=Cm(1.8)
for n in ['Normal','Title','Heading 1','Heading 2']:doc.styles[n].font.name='Calibri'
doc.styles['Normal'].font.size=Pt(10);doc.styles['Normal'].paragraph_format.space_after=Pt(6)
COL={'Green':'E2F0D9','Yellow':'FFF2CC','Red':'FCE4D6'}
def clean(t):
 t=str(t);t=re.sub(r'([,;])(?=\S)',r'\1 ',t);t=re.sub(r'(?<=\d)(?=[A-Za-z])',' ',t);t=re.sub(r'(?<=[a-z])(?=\d)',' ',t)
 for a,b in {'RQanswers':'RQ answers','resolveInferFair':'resolve InferFair','proposedtotals':'proposed totals','adjudicationrecord':'adjudication record','latestreview':'latest review','remotelyverifiedcommit':'remotely verified commit','reviewCSVreturns':'review CSV returns','andvalidation':'and validation','reportedinstruction':'reported instruction','anadditional':'an additional','Sir’smeaning':'Sir’s meaning','eachstudy':'each study','Allfive':'All five','allfive':'all five','firstdraft':'first draft','at leastone':'at least one','oneadditional':'one additional','finalchecked':'final checked','onlyto':'only to','finalacceptance':'final acceptance','ifthat':'if that','isSir':'is Sir','newerreported':'newer reported','scope559':'scope 559','retainedrecords':'retained records','actualperson':'actual person','checkedtime':'checked time','eachperson':'each person','sourcecatalogue':'source catalogue','masterworkbook':'master workbook','readingPDFs':'reading PDFs','fulltext':'full text','private location,not':'private location, not','publicrepository':'public repository','authorizedGitHubbranch':'authorized GitHub branch','Humanindependent':'Human independent','requiredscreening':'required screening','exactresponse':'exact response','completedregister':'completed register','reviewpackages':'review packages','sourcechecks':'source checks','new eligible study':'new eligible study','final report/workbook':'final report/workbook','the entire':'the entire','finalchecklist':'final checklist','alloutputs':'all outputs','actualunknowns':'actual unknowns','proofreading':'proofreading','updatedsource':'updated source','originaldecision':'original decision','actualreviewer':'actual reviewer','typesetcopy':'typeset copy','finalwritten':'final written','theprepared':'the prepared','the report':'the report','buildinstructions':'build instructions','validation summaries':'validation summaries','teamplan':'team plan','first-draftpackage':'first-draft package','andBibTeX':'and BibTeX','LaTeXsource':'LaTeX source','editableWord':'editable Word','reportPDF':'report PDF','protocol/guideline':'protocol/guideline','current masterworkbook':'current master workbook','finalsource':'final source','laterlocal':'later local','newer local':'newer local','allstudies':'all studies','minimum21':'minimum 21','asSir':'as Sir','isSir':'is Sir','target21':'target 21','21is':'21 is','instructionof':'instruction of','of21':'of 21','workingtarget':'working target','scenario count':'scenario count','finalQA':'final QA','finalchecked':'final checked','finalcorpus':'final corpus','tracedto':'traced to','whereappropriate':'where appropriate','new study':'new study','finalchecked':'final checked','reportsection':'report section'}.items():t=t.replace(a,b)
 return t

def p(t):doc.add_paragraph(clean(t))
def title(t,new=True):
 h=doc.add_heading(t,1);h.paragraph_format.page_break_before=new

def table(headers,rows,widths):
 t=doc.add_table(rows=1,cols=len(headers));t.style='Light Shading Accent 1';t.autofit=False
 for c,w in zip(t.columns,widths):c.width=Cm(w)
 for c,v in zip(t.rows[0].cells,headers):c.text=v
 z=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(z)
 for rr in rows:
  cs=t.add_row().cells
  for c,v in zip(cs,rr):
   c.text=clean(v)
   if v in COL:
    z=OxmlElement('w:shd');z.set(qn('w:fill'),COL[v]);c._tc.get_or_add_tcPr().append(z)
 for row in t.rows:
  z=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(z)
  for c,w in zip(row.cells,widths):
   c.width=Cm(w)
   for pp in c.paragraphs:
    pp.paragraph_format.space_after=Pt(4)
    for r in pp.runs:r.font.size=Pt(9)
 return t

doc.add_heading('OS CEP First-Draft Team Plan',0)
p('Topic 23: GPU sharing for multi-tenant inference | Raazia, Rameen and Eshaal | 22 October 2026')
p('The full first draft already exists. Our remaining job is to verify the evidence, make supported corrections and assemble one consistent submission. We do not need to rewrite finished sections to divide the work.')
table(['Colour','Meaning'],[['Green','The exact item stated is complete and its file/evidence exists.'],['Yellow','Work exists, but verification, correction or integration remains.'],['Red','Required work or evidence is missing.']],[2.5,14.9])
p('These colours describe individual tasks. They do not imply a completion percentage, a guaranteed mark or a finished exhaustive SLR.')
doc.add_heading('Current position',1)
table(['Item','Status','What this means'],[['Full report and editable sources','Green','Latest local master: 109-page PDF, Word, LaTeX/BibTeX and 31-tab workbook.'],['Fresh primary-source checking','Yellow','19 of the bounded 20 studies have fresh first checks across the three team packages. Human independent review remains separate.'],['InferFair P018','Red','Still missing. The ScienceDirect ZIP contains six different papers.'],['Minimum study count','Yellow','21 reports currently represent 20 unique studies. If Sir requires 21 unique studies, assess at least one more eligible study.'],['Scope closure and independent review','Red','559 retained records and actual human signoffs remain unresolved.'],['Latest GitHub publication','Red','Rameen update committed locally; latest push blocked. Earlier first draft is already on main.']],[5,2,10.4])
doc.add_heading('What changed today',1)
p('ArkGPU and Dyna-P publisher PDFs were supplied and checked. Rameen now has 50/60 QA items, 30/36 eligibility checks and 7/9 outcomes checked. Eshaal’s AI-assisted first-review package now has eight report copies, 70 QA items, 48 eligibility checks and 30 outcomes. REEF conference/journal remain one study. Master integration of these newer packages is pending.')

# Ordered practical plan.
title('1. Work order and completion checks')
steps=[
['1','Rameen / source access','Obtain the correct InferFair PDF. Match title, DOI and journal before reading.','P018 readable PDF kept privately; source URL/hash in return register.','Six eligibility checks, ten QA items and E046/E047 have anchored judgments.'],
['2','All three / count requirement','Treat Sir’s newer minimum as the working target. If it means21unique studies, assess at leastone additional eligible study using the same protocol.','New study/report IDs, selection route, QA, extraction and version link.','A qualifying unique study is added; no companion/survey is counted as an extra primary study.'],
['3','Eshaal / methods','Use the methodology audit to address search provenance and records lacking abstracts. Preserve actual unknowns.','methodology_corrections.csv with evidence and remaining gaps.','Each issue has a justified resolution or an explicit limitation.'],
['4','All three / independent rotation','Review the assigned sources separately before comparing judgments.','Completed independent columns plus disagreements.','Actual person, time, original decision and source anchor are recorded.'],
['5','Team / scope','Ask whether bounded first-draft coverage is acceptable or all559records need completion.','Dated exact instructor response, or completed screening records.','The report accurately reflects the decision and actual work.'],
['6','Raazia / integration','Apply adjudicated corrections to one master. Check all linked RQ answers, tables, recommendations and bibliography.','integration_changes.csv; rebuilt report/workbook.','No conflicting value or source status across final outputs.'],
['7','All three / final read','Read abstract, RQ answers, recommendations, conclusion and limitations. Check all required outputs.','Completed final review checklist and agreed package.','The team can explain the recommendation and trace it to the studies.']]
for no,owner,action,ret,done in steps:
 doc.add_heading(no+'. '+owner,2);p(action);p('Return: '+ret);p('Complete when: '+done)

# Task division.
title('2. Exactly what each teammate does')
table(['Person','Assigned sources','Prepared now','Still to do'],[
['Raazia','S008-S014 / P008-P014','Seven-paper AI-assisted review; 42 eligibility,70 QA,13 outcomes. Earlier corrections integrated into local master.','Independently check Rameen; resolve/adjudicate version and score issues; integrate newer corrections and rebuild final outputs.'],
['Rameen','S015-S020 / P015,P018-P022','Five sources checked;50QA,30eligibility,7outcomes;scope question and survey audit prepared.','InferFair source checks; independently check Eshaal P001-P007 and P023; review remaining survey texts; record scope response.'],
['Eshaal','S001-S007 / P001-P007 plus P023','Eight report copies checked;70QA,48eligibility,30outcomes;14methodology findings.','Independently check Raazia P008-P014; resolve methods findings with evidence; participate in Q9calibration.']],[2.2,4,5.4,5.8])
doc.add_heading('How to check one item',2)
for t in ['Open the exact PDF/version named in the source register. Find the stated page, table or figure.','Read the setup and surrounding text. Check hardware, workload, baseline, unit and whether the result is an average, percentile, maximum or ratio.','Write your own decision before viewing the other reviewer’s decision. Keep the original value and propose a correction separately.','Enter your real name and actual check time. A file-build date is not evidence that you checked the paper.','If the source is missing or unclear, write pending/unavailable and explain why. Resolve disagreement with source evidence.']:p(t)
p('Return row: Reviewer | actual time/timezone | Study ID | Report/version | item/evidence ID | original value | source page/table/figure | decision | correction | reason. The prepared AI records cannot be relabelled as independent human signatures.')

# Headings15-22.
title('3. After Task 2: headings 15-22')
table(['Heading','Status','What is already prepared','Finish before final submission'],[
['15 Taxonomy','Yellow','Mechanism categories,assumptions and boundaries in report/workbook.','Reconcile classifications with final checked corpus.'],
['16 Comparison','Yellow','Metric/context matrix with baselines,hardware and workloads.','Apply new source corrections;include new eligible studies.'],
['17 Trade-offs','Yellow','Latency/utilization/fairness/isolation and implementation costs analysed.','Verify final claim-to-source links and retain adverse results.'],
['18 Conflicting evidence','Yellow','Contextual contrasts distinguish unlike experiments.','Strengthen matched comparisons;do not call different setups contradictory.'],
['19 Synthesis','Yellow','All five RQs have draft evidence-synthesis answers.','Update answers after corrections and any new studies.'],
['20 Recommendation','Yellow','Conditional choices,benefits,sacrifices and alternatives drafted.','InferFair-dependent recommendation remains provisional;integrate checked ArkGPU/Dyna-P corrections.'],
['21 Research gaps','Yellow','Corpus-derived gaps and recent-survey comparison prepared.','Complete unavailable survey comparisons;avoid worldwide absence/first-survey claims.'],
['22 Validity','Yellow','Scope,access,reviewer and comparability limitations disclosed.','Finish mitigations where possible and retain unresolved limitations.']],[3.5,1.8,6.1,6])
p('The draft sections exist. Yellow means their final scientific verification is still open, not that they must be written from zero.')

#25 deliverables.
delivs=[
('1 Final SLR report','Yellow','109-page local draft exists;final research closure pending.'),
('2 Engineering problem','Green','Decision,alternatives,constraints and conflicting requirements are stated.'),
('3 Objectives','Green','Objectives are stated in report section1.'),
('4 3-5 RQs','Green','Five original protocol RQs retained.'),
('5 SLR protocol','Green','SubmittedTask1PDF preserved;amendments separate.'),
('6 Databases and justification','Green','Database choices and coverage rationale are written.'),
('7 Search strings','Yellow','Recorded strings supplied;field/run mapping deviations remain.'),
('8 Inclusion/exclusion criteria','Green','Criteria and implementation deviations documented.'),
('9 Database-wise results','Yellow','Recorded counts available;display/export discrepancies unresolved.'),
('10 Search/screening log','Yellow','4075canonical rows present;559not advanced;2933lack abstracts.'),
('11 Duplicate-removal record','Green','114links;unique removed IDs and valid canonical targets checked. Semantic pair audit remains separate.'),
('12 PRISMA2020flow','Yellow','Bounded flow and arithmetic present;exhaustive final selection not established.'),
('13 QA checklist/scores','Yellow','200items exist;190fresh primary-source appraisals prepared;InferFair10pending;calibration/signoff pending.'),
('14 Included primary studies','Yellow','20bounded unique studies /21reports;newer21-study instruction needs action.'),
('15 Extraction sheet','Yellow','52outcomes plus2calculations preserved;50outcomes freshly checked;InferFair2pending.'),
('16 Taxonomy','Green','Technical classification artifact exists;verification covered underheading15.'),
('17 Comparative matrix','Green','Context-aware matrix exists;final source integration still required.'),
('18 Trade-off analysis','Green','Benefits,sacrifices and conditions are drafted.'),
('19 Conflicting-evidence analysis','Yellow','Draft contrasts exist;deeper matched comparisons remain.'),
('20 All RQ answers','Green','Allfive draft answers are present;final evidence reconciliation pending.'),
('21 Engineering recommendation','Yellow','Conditional matrix exists;pending source/integration affectsfinalacceptance.'),
('22 Research gaps','Green','Gap register and proposed future work are drafted.'),
('23 Threats to validity','Green','Limitations and mitigation status are stated.'),
('24 References','Yellow','BibTeX/numbered references exist;final metadata/version audit and corrections pending.'),
('25 Supporting files','Green','Baseline,logs,CSVs,matrices,scripts and validation records exist.')]
for part,rr in enumerate([delivs[:13],delivs[13:]]):
 title('4. Heading 23: mandatory deliverables'+(' (continued)' if part else ''))
 table(['Deliverable','Status','Evidence / remaining condition'],rr,[5.3,1.8,10.3])
 p('Green applies to the stated deliverable’s existence/preparation. Read the evidence column: a prepared matrix or draft answer does not certify that every underlying study is finally verified.')

#24 fullreport.
title('5. Heading 24: report structure')
p('Use this order for the report. The section text is already drafted. The table shows what to keep and what must be checked before the team freezes the first-draft package.')
structure=[
('1 Introduction','Green','Background,engineering problem,motivation,objectives and bounded contribution.'),
('2 Research questions','Green','Five questions preserved from protocol.'),
('3 Methodology','Yellow','Protocol,databases,strings,criteria,selection,QA,extraction,synthesis;finish deviation/provenance audit.'),
('4 PRISMA selection','Yellow','Counts and flow exist;preserve559record and report/study distinctions.'),
('5 Taxonomy','Yellow','Classification drafted;reconcile source corrections.'),
('6 Results/synthesis','Yellow','Organized by RQ;update corrected evidence and confidence.'),
('7 Comparison','Yellow','Compare compatible outcomes;keep hardware/load/baseline visible.'),
('8 Trade-offs','Yellow','Link benefits and sacrifices to actual reported conditions.'),
('9 Discussion','Yellow','Explain context,conflicts and uncertainty;incorporate source review.'),
('10 Recommendation','Yellow','What,when,why,benefit,sacrifice and alternative;resolveInferFair.'),
('11 Gaps/future work','Yellow','Corpus-based gaps;refine against recent-survey overlap.'),
('12 Validity','Yellow','Disclose actual remaining scope,access,version and reviewer limits.'),
('13 Conclusion','Yellow','Consistent with finalchecked RQanswers and recommendation.'),
('References/appendices','Yellow','Search log,QA,extraction,supporting evidence;check all citations and rebuild.')]
table(['Report component','Status','What it must contain / final action'],structure,[4.5,1.8,11.1])

#25 26 expectations
title('6. Headings 25-27: analytical and evidence standard')
p('Heading25requires analysis that leads to an engineering decision. A paper-by-paper summary is insufficient. Heading26requires a verifiable research process. Heading27requires a condition-specific answer supported by the evidence.')
table(['Heading25step','Status','Simple completion check'],[
['Collect systematically','Yellow','Runs,exports,fields,filters and deviations traceable;scope limitation resolved/disclosed.'],['Critically evaluate','Yellow','Each QA item has source rationale;calibration and human checks complete.'],['Classify','Green','Explain categories and their different assumptions.'],['Compare','Yellow','Compare compatible metrics;show baseline,hardware,workload and uncertainty.'],['Analyse trade-offs','Yellow','State benefit and sacrifice for each candidate choice.'],['Synthesize','Yellow','Answer allfive RQs with multiple sources whereappropriate.'],['Make engineering decision','Yellow','Recommend what under which conditions,with reasons and alternatives.']],[4.6,1.8,11])
table(['Heading26requirement','Status','Remaining evidence check'],[
['Every included paper traceable','Yellow','FinishInferFair access and version/identity audit.'],['Every PRISMA count verifiable','Yellow','Arithmetic checked;selection/provenance closure remains.'],['Database searches reproducible','Yellow','Resolve archivedrun/export discrepancies;retain missing metadata honestly.'],['Eligibility decisions documented','Yellow','Records exist;scope/independent judgments remain.'],['No fabricated/selective evidence','Green','Preserve missing values,adverse outcomes,original scores and source boundaries.'],['Claims supported by studies','Yellow','Integrate source corrections;keepInferFair-dependent claimsprovisional.'],['Limitations/contradictions disclosed','Green','Bounded scope,access,comparability and reviewer caveats included.']],[5,1.8,10.6])
p('Heading27final question: Which GPU-sharing approach should an engineer choose for a stated workload and requirement, and what trade-offs must be accepted? Status:Yellow. The draft answers it conditionally;final acceptance depends on the checked corpus and completed integration.')

#concrete pending
title('7. Remaining actions and first-draft handover')
table(['Priority','Status','Action','Owner / return'],[
['1','Red','Supply correct InferFair full text;finish remaining10QA,6eligibility,2outcomes.','Rameen / updated source_checks_Rameen.csv'],
['2','Yellow','Meet newer21unique-study target ifthat isSir’smeaning;assess anadditional eligible study.','Team / selection,QA,extraction,counts'],
['3','Red','Get dated559-record scope decision or complete requiredscreening.','Team / exactresponse or completedregister'],
['4','Red','Perform real independent-review rotation and resolve disagreements.','Each person / independent fields'],
['5','Yellow','Resolve search-provenance discrepancies and source-version questions.','Eshaal / methodology_corrections.csv'],
['6','Yellow','Calibrate Q9consistently across allstudies before accepting proposedtotals.','Team / adjudicationrecord'],
['7','Yellow','Apply approved review changes to one master and rebuild alloutputs.','Raazia / integration_changes.csv'],
['8','Yellow','Check citations,figures,tables,page layout and final report/workbook agreement.','All three / finalchecklist'],
['9','Red','Publish the latestreview/checklist package to the authorizedGitHubbranch.','Raazia / remotelyverifiedcommit']],[1.5,1.6,9.2,5.1])
doc.add_heading('First-draft handover folder',2)
p('Include the reportPDF and editableWord;LaTeXsource andBibTeX;one current masterworkbook;reviewCSVreturns;protocol/guideline;PRISMA and counting records;sourcecatalogue;analytical matrices;the teamplan;buildinstructions andvalidation summaries. Keep copyrighted readingPDFs in their private location,not in the publicrepository.')
p('The first draft can be presented as a draft with clearly disclosed open items. Acceptance of bounded coverage must come from Sir. Do not mark a red task green merely because it appears in the document.')
doc.add_heading('Where to start',2)
p('Open task3/team/First_Draft_Team_Plan.pdf. For detailed source checks open task3/rameen and task3/eshaal. The master is task3/report/main.pdf and task3/workbook/CEP_Task3_Evidence_Workbook.xlsx. Earlier main-branch draft and newer local review packages are different checkpoints.')
p('Governing sources: docs/guidelines.md headings15-27;task1/submitted_protocol.pdf;task3/TEAM_WORK_DIVISION.md;baseline search/screening/QA/evidence registers;Raazia,Rameen,Eshaal review and validation files. The available written guideline says15-20primary studies;the newer reportedinstruction of21is retained as the workingtarget.')
# Page numbers and remove inherited heading borders.
for s in doc.sections:
 f=s.footer.paragraphs[0];f.alignment=2;field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');f._p.append(field)
for tree in [doc._element,doc.styles.element]:
 for n in list(tree.iter(qn('w:pBdr'))):n.getparent().remove(n)
doc.save(out/'First_Draft_Team_Plan.docx')
# Machine-readable status register for future updates.
(out/'First_Draft_Status.json').write_text(json.dumps({'date':'2026-10-22','deliverables':[{'item':a,'status':b,'note':c} for a,b,c in delivs],'report_structure':[{'section':a,'status':b,'note':c} for a,b,c in structure],'fresh_qa_items':190,'fresh_outcomes':50,'pending_primary_report':'P018','human_independent_signoff':False,'master_integration_pending':True,'latest_push':'blocked'},indent=2))
print('Saved First_Draft_Team_Plan.docx')
