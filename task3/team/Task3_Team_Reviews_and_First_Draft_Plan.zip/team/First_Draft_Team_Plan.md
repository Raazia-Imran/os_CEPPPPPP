Topic 23: GPU sharing for multi-tenant inference \| Raazia, Rameen and
Eshaal \| 22 October 2026

The full first draft already exists. Our remaining job is to verify the
evidence, make supported corrections and assemble one consistent
submission. We do not need to rewrite finished sections to divide the
work.

| Colour | Meaning                                                           |
|--------|-------------------------------------------------------------------|
| Green  | The exact item stated is complete and its file/evidence exists.   |
| Yellow | Work exists, but verification, correction or integration remains. |
| Red    | Required work or evidence is missing.                             |

These colours describe individual tasks. They do not imply a completion
percentage, a guaranteed mark or a finished exhaustive SLR.

# Current position

| Item                                 | Status | What this means                                                                                                                 |
|--------------------------------------|--------|---------------------------------------------------------------------------------------------------------------------------------|
| Full report and editable sources     | Green  | Latest local master: 109-page PDF, Word, LaTeX/BibTeX and 31-tab workbook.                                                      |
| Fresh primary-source checking        | Yellow | 19 of the bounded 20 studies have fresh first checks across the three team packages. Human independent review remains separate. |
| InferFair P018                       | Red    | Still missing. The ScienceDirect ZIP contains six different papers.                                                             |
| Minimum study count                  | Yellow | 21 reports currently represent 20 unique studies. If Sir requires 21 unique studies, assess at least one more eligible study.   |
| Scope closure and independent review | Red    | 559 retained records and actual human signoffs remain unresolved.                                                               |
| Latest GitHub publication            | Red    | Rameen update committed locally; latest push blocked. Earlier first draft is already on main.                                   |

# What changed today

ArkGPU and Dyna-P publisher PDFs were supplied and checked. Rameen now
has 50/60 QA items, 30/36 eligibility checks and 7/9 outcomes checked.
Eshaal’s AI-assisted first-review package now has eight report copies,
70 QA items, 48 eligibility checks and 30 outcomes. REEF
conference/journal remain one study. Master integration of these newer
packages is pending.

# 1. Work order and completion checks

## 1. Rameen / source access

Obtain the correct InferFair PDF. Match title, DOI and journal before
reading.

Return: P018 readable PDF kept privately; source URL/hash in return
register.

Complete when: Six eligibility checks, ten QA items and E046/E047 have
anchored judgments.

## 2. All three / count requirement

Treat Sir’s newer minimum as the working target. If it means 21 unique
studies, assess at least one additional eligible study using the same
protocol.

Return: New study/report IDs, selection route, QA, extraction and
version link.

Complete when: A qualifying unique study is added; no companion/survey
is counted as an extra primary study.

## 3. Eshaal / methods

Use the methodology audit to address search provenance and records
lacking abstracts. Preserve actual unknowns.

Return: methodology_corrections.csv with evidence and remaining gaps.

Complete when: Each issue has a justified resolution or an explicit
limitation.

## 4. All three / independent rotation

Review the assigned sources separately before comparing judgments.

Return: Completed independent columns plus disagreements.

Complete when: Actual person, time, original decision and source anchor
are recorded.

## 5. Team / scope

Ask whether bounded first-draft coverage is acceptable or all 559
records need completion.

Return: Dated exact instructor response, or completed screening records.

Complete when: The report accurately reflects the decision and actual
work.

## 6. Raazia / integration

Apply adjudicated corrections to one master. Check all linked RQ
answers, tables, recommendations and bibliography.

Return: integration_changes.csv; rebuilt report/workbook.

Complete when: No conflicting value or source status across final
outputs.

## 7. All three / final read

Read abstract, RQ answers, recommendations, conclusion and limitations.
Check all required outputs.

Return: Completed final review checklist and agreed package.

Complete when: The team can explain the recommendation and trace it to
the studies.

# 2. Exactly what each teammate does

| Person | Assigned sources                | Prepared now                                                                                                          | Still to do                                                                                                                     |
|--------|---------------------------------|-----------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|
| Raazia | S008-S014 / P008-P014           | Seven-paper AI-assisted review; 42 eligibility, 70 QA, 13 outcomes. Earlier corrections integrated into local master. | Independently check Rameen; resolve/adjudicate version and score issues; integrate newer corrections and rebuild final outputs. |
| Rameen | S015-S020 / P015, P018-P022     | Five sources checked; 50 QA, 30 eligibility, 7 outcomes; scope question and survey audit prepared.                    | InferFair source checks; independently check Eshaal P001-P007 and P023; review remaining survey texts; record scope response.   |
| Eshaal | S001-S007 / P001-P007 plus P023 | Eight report copies checked; 70 QA, 48 eligibility, 30 outcomes; 14 methodology findings.                             | Independently check Raazia P008-P014; resolve methods findings with evidence; participate in Q9 calibration.                    |

## How to check one item

Open the exact PDF/version named in the source register. Find the stated
page, table or figure.

Read the setup and surrounding text. Check hardware, workload, baseline,
unit and whether the result is an average, percentile, maximum or ratio.

Write your own decision before viewing the other reviewer’s decision.
Keep the original value and propose a correction separately.

Enter your real name and actual check time. A file-build date is not
evidence that you checked the paper.

If the source is missing or unclear, write pending/unavailable and
explain why. Resolve disagreement with source evidence.

Return row: Reviewer \| actual time/timezone \| Study ID \|
Report/version \| item/evidence ID \| original value \| source
page/table/figure \| decision \| correction \| reason. The prepared AI
records cannot be relabelled as independent human signatures.

# 3. After Task 2: headings 15-22

| Heading                 | Status | What is already prepared                                                  | Finish before final submission                                                                       |
|-------------------------|--------|---------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------|
| 15 Taxonomy             | Yellow | Mechanism categories, assumptions and boundaries in report/workbook.      | Reconcile classifications with final checked corpus.                                                 |
| 16 Comparison           | Yellow | Metric/context matrix with baselines, hardware and workloads.             | Apply new source corrections; include new eligible studies.                                          |
| 17 Trade-offs           | Yellow | Latency/utilization/fairness/isolation and implementation costs analysed. | Verify final claim-to-source links and retain adverse results.                                       |
| 18 Conflicting evidence | Yellow | Contextual contrasts distinguish unlike experiments.                      | Strengthen matched comparisons; do not call different setups contradictory.                          |
| 19 Synthesis            | Yellow | All five RQs have draft evidence-synthesis answers.                       | Update answers after corrections and any new studies.                                                |
| 20 Recommendation       | Yellow | Conditional choices, benefits, sacrifices and alternatives drafted.       | InferFair-dependent recommendation remains provisional; integrate checked ArkGPU/Dyna-P corrections. |
| 21 Research gaps        | Yellow | Corpus-derived gaps and recent-survey comparison prepared.                | Complete unavailable survey comparisons; avoid worldwide absence/first-survey claims.                |
| 22 Validity             | Yellow | Scope, access, reviewer and comparability limitations disclosed.          | Finish mitigations where possible and retain unresolved limitations.                                 |

The draft sections exist. Yellow means their final scientific
verification is still open, not that they must be written from zero.

# 4. Heading 23: mandatory deliverables

| Deliverable                    | Status | Evidence / remaining condition                                                                                    |
|--------------------------------|--------|-------------------------------------------------------------------------------------------------------------------|
| 1 Final SLR report             | Yellow | 109-page local draft exists; final research closure pending.                                                      |
| 2 Engineering problem          | Green  | Decision, alternatives, constraints and conflicting requirements are stated.                                      |
| 3 Objectives                   | Green  | Objectives are stated in report section 1.                                                                        |
| 4 3-5 RQs                      | Green  | Five original protocol RQs retained.                                                                              |
| 5 SLR protocol                 | Green  | SubmittedTask 1 PDF preserved; amendments separate.                                                               |
| 6 Databases and justification  | Green  | Database choices and coverage rationale are written.                                                              |
| 7 Search strings               | Yellow | Recorded strings supplied; field/run mapping deviations remain.                                                   |
| 8 Inclusion/exclusion criteria | Green  | Criteria and implementation deviations documented.                                                                |
| 9 Database-wise results        | Yellow | Recorded counts available; display/export discrepancies unresolved.                                               |
| 10 Search/screening log        | Yellow | 4075 canonical rows present; 559 not advanced; 2933 lack abstracts.                                               |
| 11 Duplicate-removal record    | Green  | 114 links; unique removed IDs and valid canonical targets checked. Semantic pair audit remains separate.          |
| 12 PRISMA2020 flow             | Yellow | Bounded flow and arithmetic present; exhaustive final selection not established.                                  |
| 13 QA checklist/scores         | Yellow | 200 items exist; 190 fresh primary-source appraisals prepared; InferFair 10 pending; calibration/signoff pending. |

Green applies to the stated deliverable’s existence/preparation. Read
the evidence column: a prepared matrix or draft answer does not certify
that every underlying study is finally verified.

# 4. Heading 23: mandatory deliverables (continued)

| Deliverable                      | Status | Evidence / remaining condition                                                               |
|----------------------------------|--------|----------------------------------------------------------------------------------------------|
| 14 Included primary studies      | Yellow | 20 bounded unique studies /21 reports; newer 21-study instruction needs action.              |
| 15 Extraction sheet              | Yellow | 52 outcomes plus 2 calculations preserved; 50 outcomes freshly checked; InferFair 2 pending. |
| 16 Taxonomy                      | Green  | Technical classification artifact exists; verification covered underheading 15.              |
| 17 Comparative matrix            | Green  | Context-aware matrix exists; final source integration still required.                        |
| 18 Trade-off analysis            | Green  | Benefits, sacrifices and conditions are drafted.                                             |
| 19 Conflicting-evidence analysis | Yellow | Draft contrasts exist; deeper matched comparisons remain.                                    |
| 20 All RQ answers                | Green  | All five draft answers are present; final evidence reconciliation pending.                   |
| 21 Engineering recommendation    | Yellow | Conditional matrix exists; pending source/integration affectsfinal acceptance.               |
| 22 Research gaps                 | Green  | Gap register and proposed future work are drafted.                                           |
| 23 Threats to validity           | Green  | Limitations and mitigation status are stated.                                                |
| 24 References                    | Yellow | BibTeX/numbered references exist; final metadata/version audit and corrections pending.      |
| 25 Supporting files              | Green  | Baseline, logs, CSVs, matrices, scripts and validation records exist.                        |

Green applies to the stated deliverable’s existence/preparation. Read
the evidence column: a prepared matrix or draft answer does not certify
that every underlying study is finally verified.

# 5. Heading 24: report structure

Use this order for the report. The section text is already drafted. The
table shows what to keep and what must be checked before the team
freezes the first-draft package.

| Report component      | Status | What it must contain / final action                                                                              |
|-----------------------|--------|------------------------------------------------------------------------------------------------------------------|
| 1 Introduction        | Green  | Background, engineering problem, motivation, objectives and bounded contribution.                                |
| 2 Research questions  | Green  | Five questions preserved from protocol.                                                                          |
| 3 Methodology         | Yellow | Protocol, databases, strings, criteria, selection, QA, extraction, synthesis; finish deviation/provenance audit. |
| 4 PRISMA selection    | Yellow | Counts and flow exist; preserve 559 record and report/study distinctions.                                        |
| 5 Taxonomy            | Yellow | Classification drafted; reconcile source corrections.                                                            |
| 6 Results/synthesis   | Yellow | Organized by RQ; update corrected evidence and confidence.                                                       |
| 7 Comparison          | Yellow | Compare compatible outcomes; keep hardware/load/baseline visible.                                                |
| 8 Trade-offs          | Yellow | Link benefits and sacrifices to actual reported conditions.                                                      |
| 9 Discussion          | Yellow | Explain context, conflicts and uncertainty; incorporate source review.                                           |
| 10 Recommendation     | Yellow | What, when, why, benefit, sacrifice and alternative; resolve InferFair.                                          |
| 11 Gaps/future work   | Yellow | Corpus-based gaps; refine against recent-survey overlap.                                                         |
| 12 Validity           | Yellow | Disclose actual remaining scope, access, version and reviewer limits.                                            |
| 13 Conclusion         | Yellow | Consistent with final checked RQ answers and recommendation.                                                     |
| References/appendices | Yellow | Search log, QA, extraction, supporting evidence; check all citations and rebuild.                                |

# 6. Headings 25-27: analytical and evidence standard

Heading 25 requires analysis that leads to an engineering decision. A
paper-by-paper summary is insufficient. Heading 26 requires a verifiable
research process. Heading 27 requires a condition-specific answer
supported by the evidence.

| Heading25step             | Status | Simple completion check                                                                       |
|---------------------------|--------|-----------------------------------------------------------------------------------------------|
| Collect systematically    | Yellow | Runs, exports, fields, filters and deviations traceable; scope limitation resolved/disclosed. |
| Critically evaluate       | Yellow | Each QA item has source rationale; calibration and human checks complete.                     |
| Classify                  | Green  | Explain categories and their different assumptions.                                           |
| Compare                   | Yellow | Compare compatible metrics; show baseline, hardware, workload and uncertainty.                |
| Analyse trade-offs        | Yellow | State benefit and sacrifice for each candidate choice.                                        |
| Synthesize                | Yellow | Answer all five RQs with multiple sources where appropriate.                                  |
| Make engineering decision | Yellow | Recommend what under which conditions, with reasons and alternatives.                         |

| Heading26requirement                 | Status | Remaining evidence check                                                          |
|--------------------------------------|--------|-----------------------------------------------------------------------------------|
| Every included paper traceable       | Yellow | FinishInferFair access and version/identity audit.                                |
| Every PRISMA count verifiable        | Yellow | Arithmetic checked; selection/provenance closure remains.                         |
| Database searches reproducible       | Yellow | Resolve archivedrun/export discrepancies; retain missing metadata honestly.       |
| Eligibility decisions documented     | Yellow | Records exist; scope/independent judgments remain.                                |
| No fabricated/selective evidence     | Green  | Preserve missing values, adverse outcomes, original scores and source boundaries. |
| Claims supported by studies          | Yellow | Integrate source corrections; keepInferFair-dependent claimsprovisional.          |
| Limitations/contradictions disclosed | Green  | Bounded scope, access, comparability and reviewer caveats included.               |

Heading 27 final question: Which GPU-sharing approach should an engineer
choose for a stated workload and requirement, and what trade-offs must
be accepted? Status:Yellow. The draft answers it conditionally; final
acceptance depends on the checked corpus and completed integration.

# 7. Remaining actions and first-draft handover

| Priority | Status | Action                                                                                           | Owner / return                              |
|----------|--------|--------------------------------------------------------------------------------------------------|---------------------------------------------|
| 1        | Red    | Supply correct InferFair full text; finish remaining 10 QA, 6 eligibility, 2 outcomes.           | Rameen / updated source_checks_Rameen.csv   |
| 2        | Yellow | Meet newer 21 unique-study target if that is Sir’s meaning; assess an additional eligible study. | Team / selection, QA, extraction, counts    |
| 3        | Red    | Get dated 559-record scope decision or complete required screening.                              | Team / exact response or completed register |
| 4        | Red    | Perform real independent-review rotation and resolve disagreements.                              | Each person / independent fields            |
| 5        | Yellow | Resolve search-provenance discrepancies and source-version questions.                            | Eshaal / methodology_corrections.csv        |
| 6        | Yellow | Calibrate Q9 consistently across all studies before accepting proposed totals.                   | Team / adjudication record                  |
| 7        | Yellow | Apply approved review changes to one master and rebuild all outputs.                             | Raazia / integration_changes.csv            |
| 8        | Yellow | Check citations, figures, tables, page layout and final report/workbook agreement.               | All three / final checklist                 |
| 9        | Red    | Publish the latest review/checklist package to the authorized GitHub branch.                     | Raazia / remotely verified commit           |

## First-draft handover folder

Include the report PDF and editable Word; LaTeX source and BibTeX; one
current master workbook; review CSV returns; protocol/guideline; PRISMA
and counting records; source catalogue; analytical matrices; the team
plan; build instructions and validation summaries. Keep copyrighted
reading PDFs in their private location, not in the public repository.

The first draft can be presented as a draft with clearly disclosed open
items. Acceptance of bounded coverage must come from Sir. Do not mark a
red task green merely because it appears in the document.

## Where to start

Open task 3/team/First_Draft_Team_Plan.pdf. For detailed source checks
open task 3/rameen and task 3/eshaal. The master is task
3/report/main.pdf and task 3/workbook/CEP_Task 3_Evidence_Workbook.xlsx.
Earlier main-branch draft and newer local review packages are different
checkpoints.

Governing sources: docs/guidelines.md headings 15-27; task
1/submitted_protocol.pdf; task 3/TEAM_WORK_DIVISION.md; baseline
search/screening/QA/evidence registers; Raazia, Rameen, Eshaal review
and validation files. The available written guideline says 15-20 primary
studies; the newer reported instruction of 21 is retained as the working
target.
