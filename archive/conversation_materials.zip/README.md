# Task 2 starter bundle | Topic 23

This is an **in-progress research workspace**, not a completed 10-mark submission. It uses the frozen `G_01_OS_CEP_SLR_Protocol_Task_1.pdf` as the protocol baseline. The separate Task 2 brief and actual deadline have not been supplied yet.

| File | Use |
|---|---|
| `TASK2_EXECUTION_PLAN.md` | Major/minor checklist, 24-hour checkpoint, 48-hour cycle, VPN export handoff and final-CEP dependencies. |
| `TASK2_Research_Tracker.xlsx` | Fourteen tabs for protocol gates, sixteen planned queries, actual runs, raw records, deduplication, screening, full texts, QA, extraction, PRISMA, amendments, final deliverables, and public discovery leads. Blank counts are intentionally blank. |
| `TASK2_REPORT_DRAFT.tex` and `references.bib` | Editable 12-point LaTeX manuscript scaffold. It cites only the methodological references currently used. |
| `TASK2_REPORT_DRAFT.pdf` | Preview of the scaffold. Red `EVIDENCE PENDING` markers make incompleteness visible. **Do not submit this PDF as completed Task 2.** |

Run the sixteen expressions on the VPN-connected laptop as the submitted protocol specifies. Upload the untouched exports and exact per-run details. Public discovery leads are separated from formal database hits and do not count in PRISMA until they enter a documented source route.

To compile the manuscript after editing: `pdflatex TASK2_REPORT_DRAFT.tex`, `bibtex TASK2_REPORT_DRAFT`, then `pdflatex TASK2_REPORT_DRAFT.tex` twice. The installed bibliography style is `ieeetr`; inspect IEEE citation and bibliography details before the final course submission.
