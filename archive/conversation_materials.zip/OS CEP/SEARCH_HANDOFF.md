# Two database searches to finish on your NED-VPN laptop

The repository already logs IEEE Xplore and Springer Nature Link. This page is for **ACM Digital Library and ScienceDirect**. Searching returns many *hits*, including irrelevant ones. You do not have to read 600 PDFs: export citations, then I can log/deduplicate/screen them. The six PDFs/Markdown papers already supplied are separate from the missing database search record.

## One search to try first on each site

Open ACM **Advanced Search**, select **The ACM Full-Text collection** (record this exact selection and the search field). On ScienceDirect open **Advanced Search** and use the **Title, abstract, or author-specified keywords** field if the site accepts the query there. This narrower field is an implementation choice to reduce full-body false matches; record it accurately. If the known seed papers disappear, try the broad field as an additional *separately logged* sensitivity search rather than quietly replacing an earlier run. Choose 2020–2026 and eligible journal/full-conference material where the site supports those filters. Exclude articles actually first published **after 11 October 2026** during screening if only year filters exist. Never assume an October issue date proves an earlier online date.

Copy the submitted protocol's master Boolean logic into the chosen site's interface:

```text
(GPU OR "graphics processing unit") AND (inference OR "model serving" OR "deep learning" OR DNN OR LLM) AND ("time slicing" OR "time sharing" OR "context switching" OR MPS OR "multi-process service" OR MIG OR "multi-instance GPU" OR "GPU partitioning" OR "API remoting" OR "CUDA remoting" OR "GPU proxy" OR "GPU virtualization")
```

If the site rejects or truncates the master, run and log **four separate searches**. The terms below are copied from the Group A protocol; the exact text accepted or transformed by the website goes in the run log.

```text
MPS: (GPU OR "graphics processing unit") AND (inference OR "model serving" OR "deep learning" OR DNN OR LLM) AND (MPS OR "multi-process service")

MIG: (GPU OR "graphics processing unit") AND (inference OR "model serving" OR "deep learning" OR DNN OR LLM) AND (MIG OR "multi-instance GPU" OR "GPU partitioning")

TEMPORAL: (GPU OR "graphics processing unit") AND (inference OR "model serving" OR "deep learning" OR DNN OR LLM) AND ("time slicing" OR "time sharing" OR "context switching")

API: (GPU OR "graphics processing unit") AND (inference OR "model serving" OR "deep learning" OR DNN OR LLM) AND ("API remoting" OR "CUDA remoting" OR "GPU proxy" OR "GPU virtualization")
```

## Record one short line **per executed search**

| File/run | Date and time | Exact pasted query and site's displayed version | Collection and field | Year/type/language filters | Displayed total hits | Number and filenames exported | Result URL or visible error |
|---|---|---|---|---|---|---|---|
| Your four ScienceDirect files: `SD_API_01.ris`, `SD_MIG_01.ris`, `SD_MPS_01.ris`, `SD_TEMPORAL_01(1).ris` | Unknown | Unknown | Unknown | Unknown | Unknown | 25 each; completeness unknown | Unknown |
| ACM master or family runs | To record | To record | ACM Full-Text collection | To record | To record or `unknown` | To record | To record |

For the *already supplied* ScienceDirect exports, please tell me what you actually remember or can see in search history; don't reconstruct a query or timestamp from a filename. An honest `unknown` is useful. Screenshot the result count/field/filters when possible and export remaining pages if there are any. Save all RIS/BibTeX citation exports; do **not** send or publish licensed full-text PDFs through GitHub. Elsevier's official [search field guide](https://www.elsevier.support/sciencedirect/answer/how-do-i-use-the-advanced-search) and [citation export guide](https://www.elsevier.support/sciencedirect/answer/how-can-i-export-my-citations) describe the controls. NED's [E-Resources list](https://eaklibrary.neduet.edu.pk/eakl/E-Resources.html) includes these platforms, but being listed does not prove access to each article.

**Send only the search-log lines/screenshots and citation exports.** I will reconcile the records with the 689 already captured, update reasons and PRISMA, then revise LaTeX, PDF, workbook and BibTeX. No new paper download request is needed at this step.
