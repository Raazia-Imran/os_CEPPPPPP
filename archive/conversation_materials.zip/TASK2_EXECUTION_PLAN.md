# Topic 23 | Task 2 execution plan and evidence gates

**Working title:** GPU Sharing Mechanisms for Multi-Tenant Inference Serving: Time-Slicing vs. MPS vs. MIG vs. API Remoting. A Study of Utilization, Latency, and Isolation in Operating Systems.

**Basis:** `CEP_Operating_Systems_guideline.pdf`, Sections 5–14 and 23–24; frozen submitted `G_01_OS_CEP_SLR_Protocol_Task_1.pdf`, 27 September 2026. The separate Task 2 brief/rubric has not yet been supplied. Treat “through Data Extraction” as the provisional boundary, and check the actual brief before submission. The 48-hour clock and exact submission time must be taken from the instructor, not inferred from this document.

## What is complete, and what is not

| Work | Status at start of Task 2 | Evidence needed to claim completion |
|---|---|---|
| Problem, objective, five RQs, scope, protocol, four planned databases, twelve main and four historical search expressions, 2020–2026 window, eligibility, screening, QA rubric, extraction form, synthesis plan | Defined in submitted Task 1 protocol | Submitted PDF, and version/freeze date |
| Formal searches across IEEE Xplore, ACM DL, ScienceDirect, Springer Nature Link | **Unexecuted here** | Per-run accepted string, interface/field/filters, local date/time, result count and original export |
| Raw record imports and deduplication | **Unexecuted** | Stable IDs, source/run links, preserved original files, duplicate decisions |
| Independent title/abstract and full-text screening | **Unexecuted** | Two initial votes, adjudication, full-text retrieval attempts and primary EC reason |
| PRISMA 2020 flow | **No actual counts yet** | Count reconciliation from the record/report/study register |
| Quality assessment and data extraction | **Form designed; no studies scored or extracted** | Source PDF, page/table anchors, independent QA scores, checked extraction rows |
| Earlier named papers | Candidate validation seeds only | Must pass formal selection before joining the included set |

The course guideline requires **15–20 final primary studies**. This is an evidence target, not a quota for fabricated inclusions. Its final report uses the wording **“min 20 to 30 pages”**, font 12, IEEE references, hard and soft copies, due **week 13**. The exact intended page minimum, week date, and separate Task 2 length should be verified with the instructor. A search yielding 500–800 *records* would not mean that many full papers have been read.

## Major checklist through guideline Section 14

- [x] **Sections 5–6, study design:** Define the OS decision, context, four mechanism families, five RQs and submitted review protocol. Preserve the submitted PDF as the frozen baseline. Log each later change with date, reason, approval and effect on reproducibility.
- [ ] **7, four NED databases:** Confirm real institutional access from the VPN-connected laptop to IEEE, ACM, ScienceDirect and Springer; retain the access outcome. Record substitutes only through an amendment. Scholar is supplementary.
- [ ] **8–9, executed searches:** Run I1–I3, A1–A3, D1–D3, S1–S3 for 1 January 2020 through each actual run date. Run H1–H4 for pre-2020 MPS. Pilot around 20 hits per expression for relevance. Log exact accepted text, field, filters, result count, time, export limit, original export filename and screenshot/citation. Keep rejected syntax and corrected syntax. Do not silently restrict a broad search.
- [ ] **10, eligibility:** Apply IC1–IC6 and EC1–EC7 as printed in the submitted PDF. Peer-reviewed full primary studies with separable same-GPU concurrent inference evidence qualify, including qualifying results from multi-GPU papers. Reviews/vendor docs/preprint-only are context, not primary evidence.
- [ ] **11, PRISMA:** Count raw records, pre-screen duplicates/other removals, unique records screened, excluded records, reports sought/not retrieved/assessed, full-text exclusions by one decisive reason, eligible reports and unique studies. Reconcile records, reports and studies separately. Populate the official diagram only from the register.
- [ ] **12, search and screening evidence:** Preserve untouched exports. Assign `R` record IDs, `P` report IDs and `S` study IDs. Store two reviewers' initial votes and timestamps, reconciled vote, conflict/adjudication, retrieval attempts and full-text page/criterion. Never overwrite an initial vote.
- [ ] **13, QA:** Calibrate two studies, apply Q1–Q10 on 0/1/2 or reasoned N/A, keep two independent scores and rationale/page anchors, calculate applicable maximum and normalized score. Lower QA alone does not automatically exclude. Later test sensitivity below 60% of applicable points.
- [ ] **14, extraction:** Pilot the form; extract one row per study × mechanism/configuration × workload/contrast × outcome. Keep identity separately. Record GPU/software, workload/tenant mix, baseline, utilization/throughput, latency quantile and load, interference and isolation evidence, methods, limitations, costs, artifact status, QA and exact source anchor. Use `NR` for unreported data; a second reviewer checks headline values.
- [ ] **Task 2 manuscript through Section 14:** Write the exact methods as executed; give actual search/selection results, PRISMA figure, included-study table, QA and extraction samples/full sheet, append complete database strings and audit trail. Label any still-pending component openly. Avoid reporting a planned step in the past tense.

## Fast cycle under the deadline

These are relative checkpoints from the team's actual start and do not assert a professor-set timestamp.

| Checkpoint | Work and concrete handoff | Stop condition |
|---|---|---|
| H0–H3 | Obtain exact Task 2 prompt/rubric and due time; freeze submitted protocol; verify four VPN database interfaces; create separate export folders and run log | Access confirmed or failed attempts documented |
| H3–H10 | Pilot all 16 queries; record errors and precision, amend only with justification; execute main and historical lanes; export every run | Each executed query has count, exact text, fields, filters, timestamp and original file |
| H10–H16 | Import exports, assign IDs, DOI then manual title/author/year dedup; preserve source links; two independent title/abstract votes | Raw-to-unique count and every decision traceable |
| H16–H24 | Reconcile screening; retrieve full texts; two independent eligibility votes; log un-retrieved reports and decisive exclusions; create actual PRISMA draft; pilot QA/extraction on available included studies | Sections 7–14 have real evidence or explicitly stated outstanding work at the 24-hour checkpoint |
| H24–H36 | Complete remaining full-text assessment and QA/extraction, depending on volume; validate source anchors and outcome units | All included studies have QA and extraction rows, or a disclosed bounded interim set |
| H36–H48 | Reconcile count arithmetic, check citations/IEEE refs, render LaTeX PDF, peer read, complete supporting files and submit | No unexplained counts, uncited empirical assertions, invented outcomes or broken file links |

If the record volume makes full-text assessment impossible in this window, do not claim it was completed. Submit a precisely bounded interim result if the Task 2 rubric allows it and ask the instructor about the required stage. Coverage and rigor outrank an arbitrary 500–800 record target.

## Database handoff from the VPN-connected laptop

1. Open the NED E-Resources page and each of the four selected database links in the same VPN-connected browser. The VPN status in OpenVPN Connect alone is not an access test. Do not share credentials or a VPN profile.
2. For each planned query in the submitted protocol, paste only the expression after its ID (`I1`, etc. are labels). Choose the specified field, year window, source collection and available document filters. If rejected, keep a screenshot/text of the rejection and log the accepted adaptation as a protocol amendment.
3. Save an export in **RIS, BibTeX, CSV or EndNote XML** with title, authors, abstract, year, venue, DOI/URL if available. Name files by database and run ID, for example `IEEE_I1_20261015.ris`. Note export pagination/caps and every batch. Save original files untouched.
4. In `Search Runs` record institution/interface, query ID, planned and exact accepted text, actual field, dates/filters, search time with timezone, on-screen count, exported count, filename, screenshot or note, and access status. A screenshot is supplementary proof, not a substitute for the export.
5. Upload the exports and the completed run log here, preferably after each database. I can then import, normalize, deduplicate, prepare screening assignments, reconcile PRISMA counts, validate records and draft the LaTeX results. Upload full-text PDFs of eligible candidates when licensing permits sharing within the team/workspace; links and page excerpts can be used otherwise.

**Software:** VPN-connected publisher interfaces for searches; Zotero or publisher exports for bibliographic interchange; the supplied workbook for record-level decisions and audit; the official PRISMA 2020 new-review flow template for reporting; LaTeX plus a `.bib` for the manuscript. Rayyan is optional for screening; export its votes and decisions back to the canonical register. PRISMA 2020 provides public Word templates and a checklist; no PRISMA account is necessary just to use them.

## Later work, Sections 15–24 and final 25 deliverables

After Task 2: classify mechanisms; build comparable outcome matrices at matching workloads/baselines; analyze utilization–latency–isolation tradeoffs and disagreements; synthesize by RQ; issue conditional recommendations; identify gaps and threats; complete IEEE references and appendices. Maintain every item in the workbook's `Final Deliverables` sheet. Do not infer a universally superior mechanism from heterogeneous studies. The final report follows the instructor's 13-section structure, not necessarily 13 pages. The 25 required outputs may be in one report plus traceable appendices/spreadsheets unless the separate Task 2 or final brief demands multiple reports.

## Source anchors

- Instructor: `CEP_Operating_Systems_guideline.pdf`, especially pp. 3–9 and 14–16 (page references can differ from PDF viewer page numbering).
- Submitted baseline: `G_01_OS_CEP_SLR_Protocol_Task_1.pdf`, especially pp. 5–13.
- NED Library E-Resources: https://eaklibrary.neduet.edu.pk/eakl/E-Resources.html
- NED Library FAQ: https://eaklibrary.neduet.edu.pk/eakl/FAQ.html
- PRISMA 2020 diagram: https://www.prisma-statement.org/prisma-2020-flow-diagram
- PRISMA 2020 checklist: https://www.prisma-statement.org/prisma-2020-checklist

**Open clarification:** Supply the instructor's exact Task 2 text/rubric and due date/time (including timezone). The currently attached guideline gives the full CEP requirements, not the standalone 10-mark Task 2 boundary.
